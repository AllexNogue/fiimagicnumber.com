# fiimagicnumber.com
Site para calcular o magic number de um Fundo imobiliário 
